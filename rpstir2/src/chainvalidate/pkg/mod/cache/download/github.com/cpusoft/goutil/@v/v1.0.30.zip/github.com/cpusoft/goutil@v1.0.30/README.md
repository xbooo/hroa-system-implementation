# goutil
some common util in golang
